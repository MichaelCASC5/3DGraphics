//Michael Calle
public class Keys{
    private boolean w,a,s,d,e,m,i,u,o,arL,arR,arU,arD,space,ctrl,shiftL;
    
    /*
        * Typed letters
    */
    public void setA(boolean b){
        a = b;
    }
    public boolean getA(){
        return a;
    }
    public void setE(boolean b){
        e = b;
    }
    public boolean getE(){
        return e;
    }
    public void setD(boolean b){
        d = b;
    }
    public boolean getD(){
        return d;
    }
    public void setI(boolean b){
        i = b;
    }
    public boolean getI(){
        return i;
    }
    public void setM(boolean b){
        m = b;
    }
    public boolean getM(){
        return m;
    }
    public void setO(boolean b){
        o = b;
    }
    public boolean getO(){
        return o;
    }
    public void setS(boolean b){
        s = b;
    }
    public boolean getS(){
        return s;
    }
    public void setU(boolean b){
        u = b;
    }
    public boolean getU(){
        return u;
    }
    public void setW(boolean b){
        w = b;
    }
    public boolean getW(){
        return w;
    }
    
    /*
        Keyboard buttons
    */
    public void setSpace(boolean b){
        space = b;
    }
    public boolean getSpace(){
        return space;
    }
    public void setShiftL(boolean b){
        shiftL = b;
    }
    public boolean getShiftL(){
        return shiftL;
    }
    public void setCtrl(boolean b){
        ctrl = b;
    }
    public boolean getCtrl(){
        return ctrl;
    }
    
    /*
        * Arrow Keys
    */
    public void setArD(boolean b){
        arD = b;
    }
    public boolean getArD(){
        return arD;
    }
    public void setArL(boolean b){
        arL = b;
    }
    public boolean getArL(){
        return arL;
    }
    public void setArR(boolean b){
        arR = b;
    }
    public boolean getArR(){
        return arR;
    }
    public void setArU(boolean b){
        arU = b;
    }
    public boolean getArU(){
        return arU;
    }
}